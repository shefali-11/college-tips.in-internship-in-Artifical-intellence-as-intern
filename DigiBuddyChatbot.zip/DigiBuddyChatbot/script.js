const faq = {
  "what is a browser": "A browser is like a window to the internet. Examples are Chrome, Firefox, and Safari.",
  "how to use whatsapp": "Open WhatsApp, tap the chat icon, select a contact, and start typing or send voice messages!",
  "how to set up email": "Go to gmail.com, click 'Create account', and follow the steps to sign up.",
  "how to pay bills online": "You can use apps like Google Pay or your bank’s app. Just log in, tap 'Pay Bills', and follow the prompts.",
  "why won’t wi-fi connect": "Make sure Wi-Fi is ON. Try restarting your phone or router. Also check the password.",
  "how to use upi": "UPI lets you send money using just a phone number or UPI ID. Apps like PhonePe and Google Pay support it.",
  "collegetips.in": "CollegeTips.in offers fun, creative internships for students to gain skills and earn from home!"
};

function sendMessage() {
  const input = document.getElementById("user-input");
  const message = input.value.trim();
  if (!message) return;

  displayMessage(message, "user");
  input.value = "";

  const response = getBotResponse(message.toLowerCase());
  speak(response);
  displayMessage(response, "bot");
}

function displayMessage(message, sender) {
  const chatBox = document.getElementById("chat-box");
  const msgDiv = document.createElement("div");
  msgDiv.className = `${sender}-message`;
  msgDiv.textContent = message;
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function getBotResponse(message) {
  for (let key in faq) {
    if (message.includes(key)) {
      return faq[key];
    }
  }
  return "Oops! I'm still learning. Try asking about browsers, email, UPI, or CollegeTips.in.";
}

function speak(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-US";
  utterance.rate = 1;
  speechSynthesis.speak(utterance);
}

function quickAsk(text) {
  document.getElementById("user-input").value = text;
  sendMessage();
}
