DigiBuddy – Friendly AI Chatbot for Digital Literacy

🔹 Description:
DigiBuddy helps parents and older users understand digital tools like email, WhatsApp, and UPI.

🧠 Features:
- Voice assistance using built-in speech synthesis
- Elder-friendly large fonts and clean layout
- Buttons for quick actions
- Preloaded answers for FAQs and digital tips
- Mobile-responsive

🚀 How to Use:
1. Open index.html in a browser.
2. Ask a tech question (e.g., “How to use WhatsApp?”)
3. DigiBuddy will respond and read it aloud!

🛠 Built With:
- HTML
- CSS
- JavaScript (no backend required)

📌 Note:
Runs fully offline in your browser. No internet or setup required!
