function adjustFontSize(size) {
  document.body.style.fontSize = size + "px";
}
